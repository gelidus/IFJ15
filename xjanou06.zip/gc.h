//
// Created by Peter on 10/16/2015.
//

#ifndef IFJ_GC_H
#define IFJ_GC_H

void* gc_malloc(int size);
void gc_free(void* x);

#endif //IFJ_GC_H
