void set_input(char *input);
int get_char();
int return_char(int c);
