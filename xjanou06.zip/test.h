//
// Created by Peter on 10/25/2015.
//

// starts only unit tests instead of interpret
// undef this to get the fully running interpret

#include "common.h"

void StartUnitTests();
